export class Auth{
    login: string;
    senha: string;
}