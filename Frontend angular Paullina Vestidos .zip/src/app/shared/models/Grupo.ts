import { Sistema } from './Sistema';
export class Grupo{
    id: number;
    nome: string;
    sistema: Sistema
}