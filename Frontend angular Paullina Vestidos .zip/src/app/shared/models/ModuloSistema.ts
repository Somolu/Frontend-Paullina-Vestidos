export class ModuleSystem{
    
}