export class SistemaDTO{
    
}