export class Telephone{
    
}