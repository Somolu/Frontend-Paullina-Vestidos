type status = 'A' | 'I';

export class Usuario{
    
}