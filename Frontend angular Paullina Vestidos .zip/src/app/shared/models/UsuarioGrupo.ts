export class UserGroup{
    
}