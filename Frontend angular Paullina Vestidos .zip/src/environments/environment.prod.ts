export const environment = {
  production: true,
  // Nome do servidor de produção - incluir serverprod no hosts da máquina (ou registrar um dns)
  // windows: c:\windows\system32\drivers\etc\hos
  // linux: /etc/hosts
  // entrada: xxx.xxx.xxx.xxx serverprod
  urlApi: 'http://serverprod:8080/modelo-api/api/v1'
};
