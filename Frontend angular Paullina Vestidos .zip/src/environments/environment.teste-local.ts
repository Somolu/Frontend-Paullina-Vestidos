export const environment = {
  production: false,
  // Nome do servidor de produção - incluir nome-servidor-teste-local no hosts da máquina (ou registrar um dns)
  // windows: c:\windows\system32\drivers\etc\hos
  // linux: /etc/hosts
  // entrada: xxx.xxx.xxx.xxx nome-servidor-teste-local
  urlApi: 'http://nome-servidor-teste-local/modelo-api/api/v1'
};
